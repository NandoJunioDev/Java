package login.loginthird;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginthirdApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginthirdApplication.class, args);
	}

}
